#ifndef ETTERCAP_PARSER_H
#define ETTERCAP_PARSER_H

EC_API_EXTERN void parse_options(int argc, char **argv);



#endif

/* EOF */

// vim:ts=3:expandtab

