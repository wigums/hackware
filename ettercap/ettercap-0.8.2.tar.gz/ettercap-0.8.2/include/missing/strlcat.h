
extern size_t strlcat(char *dst, const char *src, size_t siz);

/* EOF */
