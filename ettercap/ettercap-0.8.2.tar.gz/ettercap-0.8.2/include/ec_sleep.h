#ifndef ETTERCAP_SLEEP_H
#define ETTERCAP_SLEEP_H
EC_API_EXTERN void ec_usleep(unsigned int usecs);
#endif
