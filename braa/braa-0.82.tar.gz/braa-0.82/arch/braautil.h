
#define gmalloc(a) malloc(a)
#define grealloc(a, b) realloc(a, b)

u_int32_t * oiddup(u_int32_t * o, int l);
