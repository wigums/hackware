import api
from api import *

__all__ = ['BlindSQLi']