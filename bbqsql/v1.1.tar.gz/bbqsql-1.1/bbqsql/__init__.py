'''
bbbbbbbb           bbbbbbbb                                                                                              
b::::::b           b::::::b                                   SSSSSSSSSSSSSSS      QQQQQQQQQ     LLLLLLLLLLL             
b::::::b           b::::::b                                 SS:::::::::::::::S   QQ:::::::::QQ   L:::::::::L             
b::::::b           b::::::b                                S:::::SSSSSS::::::S QQ:::::::::::::QQ L:::::::::L             
 b:::::b            b:::::b                                S:::::S     SSSSSSSQ:::::::QQQ:::::::QLL:::::::LL             
 b:::::bbbbbbbbb    b:::::bbbbbbbbb       qqqqqqqqq   qqqqqS:::::S            Q::::::O   Q::::::Q  L:::::L               
 b::::::::::::::bb  b::::::::::::::bb    q:::::::::qqq::::qS:::::S            Q:::::O     Q:::::Q  L:::::L               
 b::::::::::::::::b b::::::::::::::::b  q:::::::::::::::::q S::::SSSS         Q:::::O     Q:::::Q  L:::::L               
 b:::::bbbbb:::::::bb:::::bbbbb:::::::bq::::::qqqqq::::::qq  SS::::::SSSSS    Q:::::O     Q:::::Q  L:::::L               
 b:::::b    b::::::bb:::::b    b::::::bq:::::q     q:::::q     SSS::::::::SS  Q:::::O     Q:::::Q  L:::::L               
 b:::::b     b:::::bb:::::b     b:::::bq:::::q     q:::::q        SSSSSS::::S Q:::::O     Q:::::Q  L:::::L               
 b:::::b     b:::::bb:::::b     b:::::bq:::::q     q:::::q             S:::::SQ:::::O  QQQQ:::::Q  L:::::L               
 b:::::b     b:::::bb:::::b     b:::::bq::::::q    q:::::q             S:::::SQ::::::O Q::::::::Q  L:::::L         LLLLLL
 b:::::bbbbbb::::::bb:::::bbbbbb::::::bq:::::::qqqqq:::::q SSSSSSS     S:::::SQ:::::::QQ::::::::QLL:::::::LLLLLLLLL:::::L
 b::::::::::::::::b b::::::::::::::::b  q::::::::::::::::q S::::::SSSSSS:::::S QQ::::::::::::::Q L::::::::::::::::::::::L
 b:::::::::::::::b  b:::::::::::::::b    qq::::::::::::::q S:::::::::::::::SS    QQ:::::::::::Q  L::::::::::::::::::::::L
 bbbbbbbbbbbbbbbb   bbbbbbbbbbbbbbbb       qqqqqqqq::::::q  SSSSSSSSSSSSSSS        QQQQQQQQ::::QQLLLLLLLLLLLLLLLLLLLLLLLL
                                                   q:::::q                                 Q:::::Q                       
                                                   q:::::q                                  QQQQQQ                       
                                                  q:::::::q
                                                  '''''''''

__title__ = 'bbqsql'
__version__ = '1.0'
__author__ = 'Ben Toews (mastahyeti)'
__license__ = 'MIT'
__copyright__ = 'Copyright 2012 Ben Toews (mastahyeti)'

from lib import *
from menu import bbqMenu 
